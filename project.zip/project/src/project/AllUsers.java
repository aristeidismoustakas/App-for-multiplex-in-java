package project;


import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *H κλάση αυτή είναι ένας χάρτης με όλους τους χρήστες που έχουν κάνει κάποια κράτηση.Ο κάθε χρήστης δίνοντας τα στοιχεία εισόδου του (που θα είναι ένα αντικείμενο 
 * της κλάσης User το οποίο θα είναι το κλειδί στον χάρτη) θα μπορεί να δει τα στοιχεία(UserData τηλέφωνο-κρατήσεις) του και να τροποποιήσει ή να διαγράψει αυτά. 
 * @author Moustakas/Mpenos
 */
public class AllUsers implements Serializable{
    private HashMap<User,UserData> allUsers;
     
    /**
     * Πρόκείται για τον constructor της κλάσης και αυτό που κανει είναι να δεσμεύει χώρο για τον χάρτη .
     */
    public AllUsers()
    {
        allUsers=new HashMap<>();
    }
      
    public AllUsers(HashMap<User,UserData> allUsers)
    {
        this.allUsers = allUsers;
    }
    
   /**
    * προσθέτει ένα νέο χρήστη(user) στον χάρτη και δημιούργει ένα αντικείμενο UserData(δίνει στον constuctor του το phone) ώστε να προστεθούν oi κρατήσεις.
    * @param user ένα αντικείμενο με τα στοιχεία name kai password του νέου χρήστη.
    * @param phone το τηλέφωνο του νέου χρήστη.
    * @return ένα αντικείμενο με τα δεδομένα του χρήστη(UserData) όπου στην συγκεκριμένη περίπτωση θα έχει μόνο το τηλέφωνο και καμία κράτηση. 
    */ 
   public UserData addUser(User user,String phone)
   {
      for(User u:allUsers.keySet())
      {
          if(u.getUsername().equals(user.getUsername()))
              return null;
      }
       UserData data=new UserData(phone);
       allUsers.put(user,data);
       return data;
   }
   
   /**
    *Δίνει σαν κλειδί στον χάρτη ένα αντικείμενο user,
    * @param user ένα αντικείμενο με τα στοιχεία name kai password του χρήστη.
    * @return ένα αντικείμενο με τα δεδομένα του χρήστη(UserData).
    */
   public UserData loginUser(User user)
   {
       if(!(allUsers.containsKey(user)))
           return null;
       else
           return allUsers.get(user);
       
   } 
   
   /**
    * Αυτή η μέθοδος χρησιμοποιείται για να αλλάξει τον κωδικό ενός χρήστη.
    * @param usr μεταβλητή τύπου User
    * @param pw μεταβλητή τύπου String
    */
   public void usrChangePw(User usr,String pw)
   {
       Set usrs = allUsers.keySet();
       Iterator<User> it = usrs.iterator();
       while(it.hasNext())
       {
           User user = it.next();
           if(user.equals(usr))
           {
               user.setPassword(pw);
               break;
           }
       }
   }
   /**
    * Αυτή η μέθοδος χρησιμοποιείται για να αλλάξει τον αριθμό τηλεφώνου ενός χρήστη.
    * @param usr μεταβλητή τύπου User
    * @param phone μεταβλητή τύπου String
    */
   public void usrChangePhone(User usr,String phone)
   {
       Set usrs = allUsers.keySet();
       Iterator<User> it = usrs.iterator();
       while(it.hasNext())
       {
           User user = it.next();
           if(user.equals(usr))
           {
               allUsers.get(user).setPhone(phone);
           }
       }
   }
   /**
    * Αυτή η μέθοδος χρησιμοποιείται για να αλλάξει τον αριθμό τηλεφώνου ενός χρήστη.
    * @param usr μεταβλητή τύπου User
    * @param phone μεταβλητή τύπου String
    */

   
      /**
    * Επιστρέφει την μεταβλητή που περιέχει τους χρήστες
    * @return το HashMap με όλους τους χρήστες
    */
   public HashMap<User,UserData> getAllUsers()
   {
       return allUsers;
   }
  
      /**
    * Μέθοδος η οποία αποθηκεύει το εκάστοτε αντικείμενο της κλάσης σε ένα αρχείο.
    */
   public void saveUsers()
   {
       try(ObjectOutputStream data=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("users.dat"))))
       {
           data.writeObject(this);
       }
       catch(Exception e)
       {
           
           System.out.println(e);
       }
   }

    /** Αναθέτει στο αντικείμενο έναν νέο χάρτη με χρήστες.
     * @param allUsers ένας νέος χάρτης με χρήστες.
     */
    public void setAllUsers(HashMap<User,UserData> allUsers) {
        this.allUsers = allUsers;
    }
   
}
