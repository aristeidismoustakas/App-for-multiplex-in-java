package project;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import java.util.*;

/**
 *
 * @author Mpenos/Moustakas
 */

/**
 * Η κλάση αυτή αναπαριστά μία αίθουσα σινεμά και κληρονομεί την κλάση Hall.
 * Περιέχει μια μεταβλητή screens(ArrayList) τύπου MovieScreen  η οποία περιέχει τις οθόνες της αίθουσας και μια μεταβλητή soundSystem τύπου String η 
 * οποία συμβολίζει το σύστημα ήχου που διαθέτει η αίθουσα.
 * 
 */
public class Cinema extends Hall implements Serializable,Comparable<Hall>
{
    private ArrayList<MovieScreen> screens;
    private String soundSystem;
    /**
     * Ο constructor της κλάσης καλεί τον κατασκευστή της μητέρας κλάσης(Hall) με την χρήση της εντολής super δίνοντας ως ορίσματα τα name kai seats 
     * που επιθυμεί ο χρήστης.Επισής αναθέτει το σύστημα ήχου((soundSystem)) που επιθυμεί ο χρήστης στο αντίστοιχο πεδίο του αντικειμένου που δημιουργείται.
     * Τέλος δεσμεύει χώρο για τις λίστα με τις οθόνες.
     * @param name το όνομα που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param seats οι θέσεις που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param soundSystem το σύστημα ήχου που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */
    public Cinema(String name,SetOfSeats seats,String soundSystem)
    {super(name, seats);
    }
    /**
     * Η μέθοδος getSoundSystem επιστρέφει το σύστημα ήχου που διαθέτει η αίθουσα.
     * @return το σύστημα ήχου(soundSystem)
     */
    public String getSoundSystem(){return soundSystem; }
    /**
     * Η μέθοδος getScreens επιστρέφει τις οθόνες της αίθουσας.
     * @return τις οθόνες(screens)
     */
    public ArrayList<MovieScreen> getScreens()
    {
        return screens;
    }
    /**
     * Η μέθοδος setSoundSystem θέτει το σύστημα ήχου της αίθουσας δοθήσας μιας παραμέτρου soundSystem.
     * @param soundSystem (το σύστημα ήχου)
     */
    public void setSoundSystem(String soundSystem)
    {
        this.soundSystem=soundSystem;
    }
     /**Η μεθοδός αυτή αναθέτει μια ανανεωμένη λίστα από οθόνες στο στο πεδίο screens. 
     * @param screens μια λίστα απ τις οθόνες ανανεωμένες
     */
    public void setScreens(ArrayList<MovieScreen> screens) {
        this.screens = screens;
    }
    
    /**
     * Η μέθοδος addScreen προσθέτει μια οθόνη στις οθόνες της αίθουσας δοθήσας μιας παραμέτρου screen.
     * @param screen η νέα οθόνη
     */
    public void addScreen(MovieScreen screen)
    {
        
    }
    /**
     * Η μέθοδος getCapacity κάνει Override την αντίστοιχη abstract μέθοδο της μητέρας κλάσης και υπολογίζει τον συνολικό αριθμό θέσεων της αίθουσας.
     * @return capacity(τον συνολικό αριθμό θέσεων)
     */
    @Override
    public int getCapacity()
    {
        return 0;
    }
    
    /**
     * Υποσκέλιση της κλάσης equals
     * @param obj
     * @return αν το αντικείμενο που κάλεσε την συνάρτηση είναι ίδιο μ αυτό που δόθηκε ως παράμετρος(οbj).
     */
    @Override
    public boolean equals(Object obj)
    {
        if(this==obj)
            return true;
        if(!(obj instanceof Cinema))
            return false;
        Cinema cin=(Cinema)obj;
        if(cin.getName().equals(this.getName()))
            return true;
        
        return false;
    }
    
    @Override
    public String toString()
    {
        return this.getName();
    }
    
    @Override
    public int compareTo(Hall hall)
    {
        return this.getName().compareTo(hall.getName());
    }
   
}
