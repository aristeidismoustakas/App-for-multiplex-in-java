package project;

import java.io.Serializable;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *Η κλάση αυτή(η οποία κληρονομεί από την κλάση Play) αναπαριστά την έννοια ενός μιας ταινίας σινεμά και περιέχει την διάρκεια(duration) της ταινίας.Επίσης περιέχει 
 * την τιμή(price),το extra ποσο για τις θέσεις πολυτελείας(plusDelux) και το extra ποσο για τις αίθουσες 3D(plus3D) όπου είναι στατικά πεδία εφόσον είναι το ίδια 
 * για όλες τις  προβολές  του έργου και γενικότερα όλων των έργων.
 * @author Moustakas/Mpenos
 * 
 */
public class CinematicFilm extends Play implements Serializable,Comparable<Play>{

    

    private double duration;
    private transient static double price;
    private transient static double plus3D;
    private transient static double plusDelux;
    
      /**
     * Πρόκειται για τον constructor της κλάσης ο οποιός καλεί τον κατασκευστή της μητέρας κλάσης(Play) με την χρήση της εντολής super δίνοντας ως ορίσματα 
     * τα name,description και director.Επίσης αναθέτει στο πεδίο διάρκεια(duration) την διάρκεια που επιθυμεί ο χρήστης.
     * @param name το όνομα που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param description  η περιγραφή που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param director ο σκηνοθέτης που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param duration η διάρκεια της ταινίας που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */ 
    public CinematicFilm(String name,String description,String director,double duration)
    {
        super(name, description, director);
        this.duration=duration;
    }
    
    /**
     * @return την διάρκεια(duration).
     */
    public double getDuration() {
        return duration;
    }

    /**
     * @return την τιμή(price)
     */
    public static double getPrice() {
        return price;
    }

    /**
     * @return το πρόσθετο ποσο για ταινίες 3D(plus3D)
     */
    public static double getPlus3D() {
        return plus3D;
    }

    /**
     * @return το πρόσθετο ποσό για πολυτελής θέσεις(plusDelux).
     */
    public static double getPlusDelux() {
        return plusDelux;
    }
    /**
     * Αναθέτει την διάρκεια που επιθυμεί ο χρήστης στο αντίστοιχο πεδίο(duration) του αντικειμένου που την καλεί.
     * @param duration η διάρκεια που επιθυμεί ο χρήστης
     */
    public void setDuration(double duration) {
        this.duration = duration;
    }
    
    /**
     * @param aPlus3D αναθέτει το aPlus3D που επιθυμεί ο χρήστης στο στατικό πεδίο plus3D.
     */
    public static void setPlus3D(double aPlus3D) 
    {
       plus3D=aPlus3D;
    }

    /**
     * @param aPlusDelux αναθέτει τo aPlusDelux που επιθυμεί ο χρήστης στο στατικό πεδίο plusDelux.
     */
    public static void setPlusDelux(double aPlusDelux) 
    {
        plusDelux=aPlusDelux;
    }
    
    /**
     * @param aPrice αναθέτει την τιμή(aPrice) που επιθυμεί ο χρήστης στο στατικό πεδίο τιμή(price).
     */
    public static void setPrice(double aPrice) 
    {
        price=aPrice;
    }
    
    /**
     * Με δεδομένα αν η θέση ειναι delux και η αίθουσα είναι 3D υπολογίζει την τιμή για κάποια θέση σε κάποια αίθουσα.
     * @param del μια boolean μεταβλητή για τον αν η θέση ειναι delux.
     * @param ThreeDim μια boolean μεταβλητή για τον αν η αίθουσα είναι 3D.
     * @return την τιμη για μια συγκεκριμένη θέση.
     */
   @Override
   public double calcPrice(boolean del,boolean ThreeDim)
   {
       if(del&&ThreeDim)
       { return getPrice()+getPlus3D()+getPlusDelux();}
       else
           if(del)
           { return getPrice()+getPlusDelux();}
       else
             if (ThreeDim)
             { return getPrice()+getPlus3D();}
       return getPrice();
          
   }
   
   
   /**
     * Υποσκέλιση της μεθόδου equals
     * @param obj
     * @return αν το αντικείμενο που κάλεσαι την συνάρτηση είναι ίδιο μ αυτό που δόθηκε ως παράμετρος(οbj).
     */
    public boolean equals(Object obj)
   {
        if(this==obj)
            return true;
        if(!(obj instanceof CinematicFilm))
            return false;
        CinematicFilm play=(CinematicFilm)obj;
        if(this.getName().equals(play.getName())&&
             this.getDirector().equals(play.getDirector())&&
             this.getPerformances().equals(play.getPerformances())&&
             this.getDescription().equals(play.getDescription())&&
             this.getActors().equals(play.getActors())&&
                getDuration()==play.duration)
        {
            return true;
        }else
            return false;
    } 
    
       /**
     * Υποσκέλιση της μεθόδου hashCode
     * @return 
     */
     @Override
    public int hashCode(){
       int hash;
       hash=this.getName().hashCode();
       hash+=this.getDescription().hashCode();
       hash+=this.getDirector().hashCode();
       hash+=getDuration()+101;
       return hash;
    }

    
        @Override
    public String toString()
    {
        return this.getName();
    }
    
    @Override
      public int compareTo(Play play)
    {
        return this.getName().compareTo(play.getName());
    }
}
