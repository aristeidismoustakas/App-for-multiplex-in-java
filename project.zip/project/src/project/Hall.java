package project;

import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Mpenos/Moustakas
 */

/**
 * Η κλάση αυτή υλοποιεί την έννοια μιας αίθουσας, είτε θεάτρου, είτε σινεμά.
 * Περιέχει  μια μεταβλητή name τύπου String στην οποία είναι αποθηκευμένο το όνομα της αίθουσας και μια μεταβλητή seats τύπου SetOfSeats η οποία περιέχει τις 
 * βασικές θέσεις μιας αίθουσας.
 * Προσδιορίζεται ότι με τον όρο βασικές θέσεις εννοούμε: Για μια αίθουσα σινεμά όλες τις θέσεις, ενώ για μια αίθουσα θεάτρου όλες τις θέσεις, εκτός από αυτές που 
 * βρίσκοντε στους εξώστες.
 * 
 */
public abstract class Hall implements Serializable,Comparable<Hall>
{
    private String name;
    private SetOfSeats seats;
    /**
     * Ο Constructor της κλάσης δίνει το όνομα(name) στο πεδίο όνομα του αντικείμενου που την καλεί και το seats(βασικές θέσεις της αίθουσας) στο 
     * αντίστοιχο πεδίο  που αντικείμενου δημιουργείται
     * @param name το όνομα που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param seats τις βασικές θέσεις που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */
    public Hall(String name,SetOfSeats seats)
    {
        this.name=name;
    }
    /**
     * Η μέθοδος getName() επιστρέφει το όνομα της αίθουσας.
     * @return το όνομα(name).
     */
    public String getName()
    {
        return name;
    }
    /**
     * Η μέθοδος setName() ορίζει το όνομα της αίθουσας (δοθήσας μιας παραμέτρου name τύπου String)
     * @param name το όνομα της αίθουσας.
     */
    public void setName(String name)
    {
        this.name=name;
    }
    /**
     * Η μέθοδος getSeats() επιστρέφει το σύνολο με τις βασικές θέσεις της αίθουσας.
     * @return το σύνολο με τις βασικές θέσεις(seats).
     */
    public SetOfSeats getSeats()
    {
        return seats;
    }
    
    /** Αναθέτει στο πεδίο θέσεις(seats) ένα νέο σύνολο(seats) από θέσεις.
     * @param seats το νέο σύνολο από θέσεις.
     */
    public void setSeats(SetOfSeats seats) {
        this.seats = seats;
    }
    
    /**
     * Η μέθοδος getCapacity υπολογίζει τον συνολικό αριθμό θέσεων της αίθουσας.
     * Είναι abstract και επομένως υλοποιείται στις κλάσεις που κληρονομούν την Hall.
     * @return τον συνολικό αριθμό θέσεων(capacity).
     */
    public abstract int getCapacity();
    
   
}

