package project;

import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Mpenos/Moustakas
 */

/**
 * Η κλάση αυτή υλοποιεί την έννοια μιας οθόνης.
 * Περιέχει μια  μεταβλητή size τύπου float που περιέχει το μέγεθος της οθόνης(σε ίντσες) και μια μεταβλητή threeDim τύπου boolean που συμβολίζει το 
 * αν η οθόνη υποστηρίζει τρισδιάστατη προβολή ή όχι. 
 * 
 */
public class MovieScreen implements Serializable
{
   private double size;
    private boolean threeDim;
    /**
     * Ο constructor της κλάσης δίνει το μέγεθος(size) και την δυνατότητα προβολής 3D που επιθυμεί ο χρήστης στα αντιστοιχα πεδία του αντικείμενου που δημιουργείται.
     * @param size  το μέγεθος που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param threedim δυνατότητα προβολής 3D που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */
    public MovieScreen(double size,boolean threeDim)
    {
        this.size=size;
        this.threeDim=threeDim;
    }
    /**
     * Η μέθοδος getSize επιστρέφει το μέγεθος της οθόνης.
     * @return το μέγεθος (size) 
     */
    public double getSize()
    {
        return size;
    }
    /**
     * Η μέθοδος getThreeDim επιστρέφει το αν μια οθόνη υποστηρίζει τρισδιάστατη προβολή ή όχι.
     * @return αν υποστηρίζει τρισδιάστατη προβολή ή όχι(threeDim).
     */
    public boolean getThreeDim()
    {
        return threeDim;
    }
    /**
     * Η μέθοδος setSize ορίζει το μέγεθος της οθόνης δοθείσας μιας παραμέτρου size.
     * @param size το μέγεθος της οθόνης.
     */
    public void setSize(double size)
    {
        this.size=size;
    }
    /**
     * Η μέθοδος setThreeDim ορίζει το αν μια οθόνη υποστηρίζει τρισδιάστατη προβολή ή όχι δοθείσας μιας παραμέτρου threeDim
     * @param threeDim το αν μια οθόνη υποστηρίζει τρισδιάστατη προβολή ή όχι
     */
    public void setThreeDim(boolean threeDim)
    {
        this.threeDim=threeDim;
    }
}
