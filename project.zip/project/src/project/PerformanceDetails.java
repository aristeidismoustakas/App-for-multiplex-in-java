package project;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *Η κλάση αυτή αναπαριστά τα στοχεία μιας συγκεκριμμένης προβολής-παράστασης.
 * Η κλάση αυτή περιέχει την ημέρα και την ώρα(day) της συγκέκριμμενης  προβολής-παράστασης και την αίθουσα(hall) οπου γινεται η προβολή-παράσταση.
 * @author Moustakas/Mpenos
 */
public class PerformanceDetails implements Serializable,Comparable<PerformanceDetails>{
   private Date day;
   private Hall hall;

    /**
     * Πρόκειται για τον construsctor της κλάσής,αναθέτει αρχικές τιμές στα πεδία του αντικειμένου.
     * @param day η μέρα και η ώρα που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param hall η αίθουσα που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */
    public PerformanceDetails(Date day,Hall hall)
    {
        this.day=day;
        this.hall=hall;
    }
    
    
    /**
     * @return την ημέρα και την ωρα(day)
     */
    public Date getDay() 
    {
        return day;
    }

    /**
     * @param day αναθέτει την ημέρα(day) που επιθυμεί ο χρήστης στο πεδίο ημέρα(day) του αντικειμένου που την καλεί.
     */
    public void setDay(Date day) 
    {
        this.day=day;
    }


    /**
     * @return την αίθουσα(hall)
     */
    public Hall getHall() 
    {
        return hall;
    }

    /**
     * @param hall αναθέτει την αίθουσα(hall) που επιθυμεί ο χρήστης στο πεδίο αίθουσα(hall) του αντικειμένου που την καλεί.
     */
    public void setHall(Hall hall) throws Exception 
    {
      // amuntiki antigrafi
       ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(buffer)) {
            out.writeObject(hall);
        }
        try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(buffer.toByteArray()))) {
            this.hall = (Hall) in.readObject(); 
        }
    }
    
   @Override
    public String toString()
    {
        String dayy,month,year,hours,min;
        if(day.getDate()<10)
            dayy="0"+day.getDate()+"";
        else
            dayy=day.getDate()+"";
        
         if(day.getMonth()<10)
            month="0"+day.getMonth()+"";
        else
            month=day.getMonth()+"";
         
          if(day.getHours()<10)
            hours="0"+day.getHours()+"";
        else
            hours=day.getHours()+"";
          
          if(day.getMinutes()<10)
            min="0"+day.getMinutes()+"";
        else
            min=day.getMinutes()+"";

        year=day.getYear()+"";

        return "Ημερομηνία: "+dayy+"/"+month+"/"+year+"   Ώρα: "+hours+":"+min+"  Αίθουσα: "+hall;
       // return day+"  Αίθουσα: "+hall;
    }
    
  @Override
    public int compareTo(PerformanceDetails t)
    {
        return this.day.compareTo(t.getDay());
    }

  
   @Override
    public boolean equals(Object p)
    {
        PerformanceDetails per=(PerformanceDetails) p;
        return (day.equals(per.day)&&hall.equals(per.hall));
    }
    
    
}
