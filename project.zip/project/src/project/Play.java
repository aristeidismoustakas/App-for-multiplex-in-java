package project;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Η κλάση αυτή αναπαριστά την έννοια ενός έργου,είτε θεατρικού είτε ταινίας σινεμά.
 * Αυτή η κλάση περιέχει το όνομα(name) του έργου,την περιγραφή(description) του έργου,τον σκηνοθέυη(director) του έργου,ένα σετ με 
 * τους ηθοποιούς(actors) του εργου και ένα σετ(perfomances) όπου περιεχει τις πληροφορίες για τις προβολές του έργου
 */
public abstract class  Play implements Serializable,Comparable<Play>{
   private String name;
   private String description;
   private String director;
   private HashSet<String> actors=null;
   private HashSet< PerformanceDetails> performances; 

    
   /**
    *  Πρόκειται για τον construsctor της κλάσής,αναθέτει το όνομα(name),την περιγραφή(description) και τον σκηνοθέτη(director) τις τιμές που επιθυμεί ο χρήστης και
    * δεσμεύει χώρο για την λίστα με τους ηθοποιούς και για την λίστα όπου περιεχει τις πληροφορίες για τις προβολές του έργου.
    * @param name το όνομα που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
    * @param description  η περιγραφή που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
    * @param director ο σκηνοθέτης που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
    */
    public Play(String name,String description,String director)
    {
        this.name=name;
        this.description=description;
        this.director=director;
        actors=new HashSet<>();
        performances=new HashSet<>();
    }
    
   
    /**
     * @return το πεδίο ονομα(name) 
     */
    public String getName()
    {
        return name;
    }
       

    /**
     * @param name αναθέτει αναθέτει ένα όνομα(name) που επιθυμεί ο χρήστης στο πεδίο όνομα(name) του αντικειμένου που την καλεί.
     */
    public void setName(String name) 
    {
        this.name=name;
    }
   
    /**
     * @return την περιγραφή(description)
     */
    public String getDescription() 
    {
        return description;
    }
  
    /**
     * @param description αναθέτει μια περιγραφή(description) που επιθυμεί ο χρήστης στο πεδίο περιγραφή(description) του αντικειμένου που την καλεί.
     */
    public void setDescription(String description)
    {
        this.description=description;
    }

    /**
     * @return τον σκηνοθέτη(director)
     */
    public String getDirector() 
    {
        return director;
    }
    
    /**
     * @param director αναθέτει τον σκηνοθέτη(director) που επιθυμεί ο χρήστης στο πεδίο σκηνοθέτης(director) του αντικειμένου που την καλεί.
     */
    public void setDirector(String director) 
    {
        this.director=director;
    }

    /**
     * @return ενα σετ με τους ηθοποιούς του έργου.
     */
    public HashSet<String> getActors() 
    {
        return actors;
    }


    /**
     * @param actors αναθέτει ενα σετ με τους ηθοποιούς του έργου(actors) που επιθυμεί ο χρήστης στο πεδίο ηθοποιοί(actors) του αντικειμένου που την καλεί.
     */
    public void setActors(HashSet<String> actors) 
    {
        this.actors=actors;
    }

    /**
     * @return ενα σετ με τις προβολές του έργου(performances).
     */
    public HashSet< PerformanceDetails> getPerformances() 
    {
        return performances;
    }

    /**
     * @param performances αναθέτει ενα σετ με τις προβολές του έργου(performances) που επιθυμεί ο χρήστης στο πεδίο προβολές του έργου(performances) του αντικειμένου που την καλεί.
     */
    public void setPerformances(HashSet< PerformanceDetails> performances) 
    {
        this.performances=performances;
    }
    
    
      
   /**
    * H μέθοδος αυτή είναι απλά μια υπογραφή της calcPrice η οποία υπολογίζει την τιμή τους εισητηρίου για μια συσκεκριμένη ταίνια ή παράσταση
    * (στις ταινίες παίζει ρόλο και αν η καρέκλα είναι πολυτελείας και αν η προβολή ειναι 3D).
    * @param del αν η θέση είναι πολυτελείας.
    * @param ThreeDim αν η προβολή είναι 3D.
    * @return την τιμή(price)
    */
    public abstract double calcPrice(boolean del,boolean ThreeDim);
    
    
}
