package project;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *Η κλαση αυτή περιέχει τα στοιχεία για μια κράτηση ενός χρήστη.Πιο συγκεκριμένα περιέχει τα στοιχεία της προβολής(details) και και μια λίστα από τις θέσεις(seatRes) που έχει
 * κρατήσει ο χρήστης.
 * @author Moustakas/Mpenos
 */
public class Reservation implements Serializable{
    private PerformanceDetails details;
    private ArrayList<SeatRes> seatsRes;

    /**
     * Πρόκειται για τον constructor της κλάσης ο οποίος δέχεται σαν όρισμα τα στοιχεία της προβολής(details)
     * και τα αναθέτει στa αντίστοιχο πεδίo details του αντικειμένου που την καλεί.Eπίσης δεσμεύει χώρο για
     *  λίστα που περιέχει τις θέσεις(seatRes)
     * @param details  τα στοιχεία της προβολης.
     */
    public Reservation(PerformanceDetails details)
    {
        this.details=details;
        seatsRes=new ArrayList<>();
    }
    
    /**
     * Επιστρέφει τα στοιχεία της προβολης(details).
     * @return τα στοιχεία της προβολης(details).
     */
    public PerformanceDetails getDetails() 
    {
        return details;
    }

    /**
     * αναθέτει τα στοιχεία προβολής(details) που επιθυμεί ο χρήστης στα στοιχεία προβολής(details) του αντικειμένου που την καλεί.
     * @param details τα στοιχεία προβολής.
     */
    public void setDetails(PerformanceDetails details) 
    {
        this.details=details;
    }

    /**
     * προσθέτει στην υπάρχουσα λίστα με τις κρατήσεις(seatRes) κάποιες κρατήσεις ακόμα που βρίσκονται μέσα στην λίστα(seats)
     * @param seats οι νέες κρατήσεις
     */
    public void addSeats(SeatRes seat)
    {
        seatsRes.add(seat);
    }
    
    
    /**
     *διαγράφει μια θέση με βάση τις "συντεταγμενες"(row,seat,balconie) της από την λίστα με τις κρατημένες θέσεις(seatRes).
      * @param row η θέση 
     * @param seat η σειρά
     * @param balconie ο εξώστης
     */
    public void deleteSeatRes(int row,int seat,int balconie)
    {
        SeatRes res=new SeatRes(row, seat, balconie);
        Iterator<SeatRes> it=getSeatsRes().iterator();
        while(it.hasNext())
        {
            SeatRes r=it.next();
            if(r.equals(res))
            {
                it.remove();
                break;
            }
        }
    }

    
     /**
     * προσθέτει στην υπάρχουσα λίστα με τις κρατήσεις(seatRes) κάποιες κρατήσεις ακόμα που βρίσκονται μέσα στην λίστα(seats)
     * @param seats οι νέες κρατήσεις
     */
    public void addSeats(ArrayList<SeatRes> seats)
    {
        seatsRes.addAll(seats);
    }
    /**
     * @return την λίστα με τις κρατημένες θέσεις.
     */
    public ArrayList<SeatRes> getSeatsRes() {
        return seatsRes;
    }

    /** Αναθέτει μια νέα λίστα με κρατημένες θέσεις.
     * @param seatsRes η νέα λίστα με κρατημένες θέσεις.
     */
    public void setSeatsRes(ArrayList<SeatRes> seatsRes) {
        this.seatsRes = seatsRes;
    }

    @Override
   public String toString()
   {
       return details.toString()+"  "+seatsRes.size()+"  "+" Κρατήσεις";
   }
    
}
