package project;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import java.util.*;
import static java.util.Collections.list;

/**
 *
 * @author Mpenos/Moustakas
 */

/**
 * Αυτή η κλάση απεικονίζει μια σειρά(λίστα) από θέσεις.
 * Περιέχει ένα πεδίο row(ArrayList) τύπου Seat στο οποίο και περιέχοντε οι θέσεις.
 * 
 */
public class RowOfSeats implements Serializable
{
    ArrayList<Seat> row;
    /**
     * Ο constructor της κλάσης δεσμεύει χώρο για την μεταβλητή row.
     */
    public RowOfSeats(){
    row=new ArrayList<>();
    }
    
    /**
     * Η μέθοδος addSeat προσθέτει μια θέση(seat) στην σειρά(λίστα).
     * @param seat η θέση.
     */
    public void addSeat(Seat seat){
    row.add(seat);}
    
    /**
     * Η μέθοδος getRow επιστρέφει την σειρά με τις θέσεις.
     * @return την σειρά (row).
     */
    public ArrayList<Seat> getRow(){return row;}
    
    /**
     * Αναθέτει στο πεδίο σειρά row μια νέα σειρά(aRow) με θέσεις.
     * @param aRow η νέα σειρά
     */
    public void setRow(ArrayList<Seat> aRow)
    {
        row=aRow;
    }
    
       /**
     * Η μέθοδος getTotalNumOfSeats επιστρέφει τον συνολικό αριθμό θέσεων στο σετ θέσεων.
     * @return τον συνολικό αριθμό θέσεων.
     */
    /* public int getTotalNumOfSeats()
    {
        Iterator<RowOfSeats> it = list.iterator();
        int c = 0;
        while(it.hasNext())
        {
            RowOfSeats row = it.next();
            c += row.getNumOfSeats();
        }
        return c;
    }*/
    
      /**
     * Η μέθοδος getNumOfSeats επιστρέφει τον αριθμό των θέσεων στη σειρά.
     * @return τον αριθμό θέσεων
     */
    
    public int getNumOfSeats()
    {
        return row.size();
    }
}
