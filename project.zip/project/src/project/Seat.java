package project;

import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Mpenos/Moustakas
 */

/**
 * Αυτή η κλάση υλοποιεί την έννοια μιας θέσης.
 * Περιέχει τα εξής πεδία: Μια μεταβλητή delux τύπου boolean η οποία συμβολίζει το αν η θέση είναι πολυτελείας και μια μεταβλητή 
 * empty τύπου boolean η οποία συμβολίζει το αν η θέση είναι πιασμένη ή όχι.
 */
public class Seat implements Serializable
{
    private boolean delux=false;
    private boolean empty=true;
    /**
     * Ο constructor της κλάσης δίνει στα πεδία delux και empty τις τιμές delux και empty που επιθυμεί ο χρήστης.
     * @param delux αν η θέση είναι πολυτελείας
     * @param empty αν η θέση είναι πιασμένη ή όχι.
     */
    public Seat(boolean delux,boolean empty)
    { 
        this.delux=delux;
        this.empty=empty;
    }
    /**
     * Η μέθοδος getDelux επιστρέφει το αν η θέση είναι πολυτελείας ή όχι.
     * @return delux αν πολυτελείας ή όχι.
     */
    public boolean getDelux(){return delux;}
    /**
     * Η μέθοδος getEmpty επιστρέφει το αν η θέση είναι άδεια ή όχι.
     * @return empty
     */
    public boolean getEmpty(){return empty;}
    /**
     * Η μέθοδος setDelux δίνει στην θέση την ιδιότητα του αν είναι πολυτελείας ή όχι βάση της παραμέτρου delux.
     * @param delux 
     */
    public void setDelux(boolean delux)
    {
        this.delux=delux;
    }
    /**
     * Η μέθοδος setEmpty δίνει στην θέση την ιδιότητα του αν είναι άδεια ή όχι βάση της παραμέτρου empty.
     * @param empty 
     */
    public void setEmpty(boolean empty)
    {
        this.empty=empty;
    }
}
