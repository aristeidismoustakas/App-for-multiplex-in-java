package project;

import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * H κλάση αυτή αναπαριστά της συντεταγμένες μιας καρεκλας δηλαδή σειρα(row),θέση(seat) και εξώστη(balconie)(αν βρίσκεται σε εξώστη θα δίνεται ο αριθμός του εξώστη αλλιώς
 * η τιμή 0).Κάθε αντικείμενο αυτής της κλάσης θα αποτελεί την κράτηση μιας θέσης.
 * @author Moustakas/Mpenos
 */
public class SeatRes implements Serializable{
   private int row;
   private int seat;
   private int balconie;
    
    /**
     * Πρόκειται για τον constructor της κλάσης , αναθέτει την σειρά(row),τον αριθμό θέσης(seat),και τον εξώστη(balconie) που επιθυμεί ο χρήστης στα αντίστοιχα πεδία 
     * σειρά(row),αριθμό θέσης(seat),και εξώστη(balconie) του αντικειμένου που την καλεί.
     * @param row η σειρά που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param seat η θέση που επιθυμεί ο χρήστης.
     * @param balconie ο εξώστης που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */
    public SeatRes(int row,int seat,int balconie)
    {
       this.balconie=balconie;
       this.row=row;
       this.seat=seat;
    }
    
    
    /**Υποσκέλιση της μεθόδου equals
     * @param obj
     * @return αν το αντικείμενο που κάλεσαι την συνάρτηση είναι ίδιο μ αυτό που δόθηκε ως παράμετρος(οbj).
     */
   @Override
    public boolean equals(Object obj)
    {
         if(this==obj)
            return true;
        if(!(obj instanceof SeatRes))
            return false;
        SeatRes res=(SeatRes)obj;
        if(getRow()==res.getRow()&&getSeat()==res.getSeat()&&getBalconie()==res.getBalconie())
        {
            return true;
        }else
            return false;
    }
     
    @Override
    public int hashCode(){
       return getRow()+2*getSeat()+3*getBalconie()+49;
    }

    /**
     * @return the row
     */
    public int getRow() {
        return row;
    }

    /**
     * @param row the row to set
     */
    public void setRow(int row) {
        this.row = row;
    }

    /**
     * @return the seat
     */
    public int getSeat() {
        return seat;
    }

    /**
     * @param seat the seat to set
     */
    public void setSeat(int seat) {
        this.seat = seat;
    }

    /**
     * @return the balconie
     */
    public int getBalconie() {
        return balconie;
    }

    /**
     * @param balconie the balconie to set
     */
    public void setBalconie(int balconie) {
        this.balconie = balconie;
    }
    
}