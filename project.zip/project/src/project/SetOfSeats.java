package project;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import java.util.*;

/**
 *
 * @author Mpenos/Moustakas
 */

/**
 * Η κλάση αυτή αναπαριστά μια λίστα, από σειρές, από θέσεις.
 * Περιέχει ένα πεδίο list(ArrayList ) τύπου RowOfSeats το οποίο και περιέχει τις σειρές των θέσεων.
 * 
 */
public class SetOfSeats implements Serializable 
{
    private ArrayList<RowOfSeats> list;
    /**
     * Ο constructor της κλάσης δεσμεύει χώρο για την μεταβλητή set.
     */
    public SetOfSeats(){
    list=new ArrayList<>();
    }
    /**
     * Η μέθοδος addRow προσθέτει μιά σειρά(row) από θέσεις στη λίστα των σειρών. 
     * @param row  η σειρά
     */
    public void addRow(RowOfSeats row)
    {
        list.add(row);
    }
    /**
     * Η μέθοδος getList επιστρέφει την λίστα με τις σειρές θέσεων.
     * @return την λίστα(set)
     */
    public ArrayList<RowOfSeats> getList(){
        return list;
    }

    /**Aναθέτει μια λίστα από θέσεις(list) στο αντίστοιχο πεδίο(list)
     * @param list η νεα λίστα από θέσεις
     */
    public void setList(ArrayList<RowOfSeats> list) {
        this.list = new ArrayList<>(list);
    }
}
