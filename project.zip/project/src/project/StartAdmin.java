package project;

import GUI.MyFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * H κλάση αυτή χρησιμοποιείται για την κλήση των κατάλληλων μεθόδων αναλογα με τις απαιτήσεις του χρήστη  όταν αυτο χρησιμοιποιειται από τον διαχειρηστή 
 * του πολυχώρου.
 * @author Moustakas/Mpenos
 */
public class StartAdmin implements StartProgramm{
  
    /**
     * ο constructor της κλάσης που έιναι κενός.
     */
   // ListOfHalls halls;
    public StartAdmin(){}
    
    
    /**
     *  Η μέθοδος αυτή καλείται για να κάνει την διαχείρηση του προγράμματος όταν αυτό χρησιμοποιείται από τον διαχειριστή.Ο διαχειριστής θα μπορεί να προσθέτει αίθουσες
     * να τροποποιεί αίθουσες και να αφαιρεί αίθουσες.Επίσης ο διαχειριστής θα μπορεί να προσθέσει κάποια νέα κινηματογραφική ταινία ή θεατρική παράσταση,να αφαιρέσει 
     * κάποια από αυτές,η να τροποποιήσει κάποιο από τα πεδία τους(ονομα,περιγραφη,ηθοποιούς,προβολές κτλ).  
     */
    @Override
    public void start()
    {
       /* halls=new ListOfHalls();
        halls.addHall(new Cinema("prwti", null, "high"));
        halls.addHall(new TheatricalHall("deuteri", null, 10));
        halls.addHall(new Cinema("triti", null, "double high"));*/
       
    } 
    public static void main(String[] args) {
         MyFrame a=new MyFrame();
        a.setVisible(true);
    }
}
