package project;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *Ένα interface που ουσιαστικά κάνει την διαχείρηση όλου του προγράμματος(αφού από αυτό κληρονομούν οι κλάσεις StartAdmin και StartUser που κάνουν την διαχείρηση υου 
 * διαχειρηστή και του πελάτη αντίστοιχα).
 * @author Moustakas/Mpenos
 */
public interface StartProgramm {
    

    /**
     * Είναι μια υπογραφή της μεθόσου start() που υπάρχει και στις κλάσεις StartAdmin και στην StartUser.
     */
    public void start();
}
