package project;

import GUI.LoggedUser;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * H κλάση αυτή χρησιμοποιείται για την κλήση των κατάλληλων μεθόδων αναλογα με τις απαιτήσεις του χρήστη  όταν αυτο χρησιμοιποιειται από κάποιον πελάτη του 
 * πολυχώρου. 
 * @author Moustakas/Mpenos
 */
public class StartUser implements StartProgramm{
    /**
     * ο constructor της κλάσης που έιναι κενός
     */
    public StartUser(){}
    
    /**
     * Η μέθοδος αυτή καλείται για να κάνει την κλήση των κατάλληλων μεθόδων του προγράμματος όταν αυτό χρησιμοποιείται από κάποιον πελάτη.Αρχικά διαχωρίζει εάν ο χρήστης είναι νεος η ξαναέχει κάνει κάποια άλλη κράτηση.Αν ο χρήστης δεν έχει ξαναμπεί στο σύστημα θα του ζητάει κάποια στοιχεία(Οπως ονομα,κωδικο,τηλεφωνο) 
     * και στην συνέχεια  θα μπορεί αυτός να κάνει τις κρατήσεις που θέλει.Αν ο χρήστης έχει ξαναμπεί στο σύστημα(έχει ξανακάνει κράτηση) θα ζητάτε ο το όνομα του 
     * και ο κωδικός του και στην συνέχεια θα μπορεί να δει τις κρατήσεις που εχει κάνει,να κάποια καινούρια,να διαγράψει κάποια απ τις παλιές ή να τροποιήση κάποια 
     * απ αυτές. 
     */
    @Override
    public void start(){}
    public static void main(String[] args) {
        LoggedUser u=new LoggedUser();
        u.setVisible(true);
    }
    
}
