package project;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import java.util.*;

/**
 *
 * @author Mpenos/Moustakas
 */

/**
 * Η κλάση αυτή απεικονίζει μία αίθουσα θεατρικών παραστάσεων και κληρονομεί την κλάση Hall.
 * Περιέχει μια μεταβλητή dressingRooms τύπου int που περιέχει των αριθμό των καμαρινιών της αίθουσας και μια μεταβλητή balconies 
 * τύπου ArrayList που περιέχει μια λίστα με τους εξώστες της αίθουσας, υλοποιημένους ως "σύνολα" θέσεων.
 *
 */
public class TheatricalHall extends Hall implements Serializable,Comparable<Hall>
{
    private int dressingRooms;
    private ArrayList<SetOfSeats> balconies;
   /**
     * Ο constructor της κλάσης καλεί τον κατασκευστή της μητέρας κλάσης(Hall) με την χρήση της εντολής super δίνοντας ως ορίσματα τα name kai seats 
     * που επιθυμεί ο χρήστης.Επισής αναθέτει τον αριθμο των καμαρινιών(dressingRooms) που επιθυμεί ο χρήστης στο αντίστοιχο πεδίο του αντικειμένου 
     * που δημιουργείται.
     * Τέλος δεσμεύει χώρο για τις λίστα με τις εξώστες.
     * @param name το όνομα που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param seats οι θέσεις που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param dressingRooms καμαρινιών που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */
    public TheatricalHall(String name,SetOfSeats seats, int dressingRooms)
    {
        super(name, seats);
    }
    /**
     * Η μέθοδος getDressingRooms επιστρέφει τον αριθμό των καμαρινιών της αίθουσας.
     * @return dressingRooms
     */
    public int getDressingRooms(){return dressingRooms;}
    /**
     * Η μέθοδος SetOfSeats επιστρέφει την λίστα balconies με τους εξώστες της αίθουσας.
     * @return balconies
     */
    public ArrayList<SetOfSeats> getBalconies(){return balconies;}
    /**
     * Η μέθοδος setDressingRooms θέτει τον αριθμό των καμαρινιών της αίθουσας δοθήσας μιας παραμέτρου dressingRooms.
     * @param dressingRooms τα καμαρίνια.
     */
    public void setDressingRooms(int dressingRooms)
    {
        this.dressingRooms=dressingRooms;
    }
    /**
     * Η μέθοδος addBalcony προσθέτει έναν εξώστη στην αίθουσα δοσμένου ενός συνόλου από θέσεις.
     * @param balcony ο νέος εξώστης
     */
    public void addBalcony(SetOfSeats balcony)
    {
        balconies.add(balcony);
    }
    /**
     * Η μέθοδος getCapacity κάνει Override την αντίστοιχη abstract μέθοδο της μητέρας κλάσης και υπολογίζει τον συνολικό αριθμό θέσεων της αίθουσας.
     * @return  τον συνολικό αριθμό θέσεων(capacity).
     */
    @Override
    public int getCapacity(){return 0;}
    
    /**
     * Υποσκέλιση της κλάσης equals
     * @param obj
     * @return αν το αντικείμενο που κάλεσε την συνάρτηση είναι ίδιο μ αυτό που δόθηκε ως παράμετρος(οbj).
     */
    @Override
    public boolean equals(Object obj)
    {   if(this==obj)
            return true;
        if(!(obj instanceof TheatricalHall))
            return false;
        TheatricalHall cin=(TheatricalHall)obj;
        if(cin.getName().equals(this.getName()))
            return true;
        
        return false;
    }
    
       @Override
    public String toString()
    {
        return this.getName();
    }

    /**
     * Αναθέτει στο πεδίο εξώστες(balconies) μια  νεα λίστα από εξώστες(balconies) 
     * @param balconies η νέα λίστα από εξώστες
     */
    public void setBalconies(ArrayList<SetOfSeats> balconies) {
        this.balconies=balconies;
    }

    @Override
     public int compareTo(Hall hall)
    {
        return this.getName().compareTo(hall.getName());
    }
    
}
