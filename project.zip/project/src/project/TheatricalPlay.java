package project;

import java.awt.PageAttributes;
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *Η κλάση αυτή(η οποία κληρονομεί από την κλάση Play) αναπαριστά την έννοια ενός θεατρικού εργου και περιέχει ένα πεδίο με την τιμή(price) του εισητιρίου της παράστασης.
 * @author Moustakas/Mpenos
 */
public class TheatricalPlay extends Play implements Serializable,Comparable<Play>{

     private double price;
    
    
    /**
     *  Πρόκειται για τον constructor της κλάσης ο οποιός καλεί τον κατασκευστή της μητέρας κλάσης(Play) με την χρήση της εντολής super δίνοντας ως ορίσματα 
     * τα name,description και director που επιθυμεί ο χρήστης.Επίσης αναθέτει στο πεδίο τιμή(price) την τιμή που επιθυμεί ο χρήστης.
     * @param name το όνομα που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param description η περιγραφή που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param director ο σκηνοθέτης που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     * @param price η τιμή που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */    
    public TheatricalPlay(String name,String description,String director,double price){
    super(name, description, director);
    this.price=price;
    }
    
 /**
  * Ουσιαστικά είναι μια συνάρτηση που επιστρέφει την τιμή(price) για μια θέση σε κάποια παράσταση(τα δύο ορίσματα del και ThreeDim είναι περιττά,απλά τα δηλένουμε γιατί η
  * calcPrice είναι abstract).
  * @param del μια boolean μεταβλητή για τον αν η θέση ειναι delux(είναι πάντα false γιατί οι θεατρικές αίθουσες δεν έχουμ delux θέσεις).
  * @param ThreeDim μια boolean μεταβλητή για τον αν η αίθουσα είναι 3D(είναι πάντα false γιατί οι θεατρικές αίθουσες δεν είναι ποτέ 3D).
  * @return την τιμή(price)
  */
    @Override
   public double calcPrice(boolean del,boolean ThreeDim)
   {
       return price;
    }
   
   
   /**
    * @param price αναθέτει την τιμή(price) που επιθυμεί ο χρήστης στο πεδίο τιμή(price) του αντικειμένου που την καλεί.
    */
    public void setPrice(double price) {
        this.price=price;
    
    }
   
   /**
     * Υποσκέλιση της μεθόδου equals
     * @param obj
     * @return αν το αντικείμενο που κάλεσαι την συνάρτηση είναι ίδιο μ αυτό που δόθηκε ως παράμετρος(οbj).
     */
     @Override
    public boolean equals(Object obj)
    {
        if(this==obj)
            return true;
        if(!(obj instanceof TheatricalPlay))
            return false;
        TheatricalPlay play=(TheatricalPlay)obj;
        if(this.getName().equals(play.getName())&&
             this.getDirector().equals(play.getDirector())&&
             this.getPerformances().equals(play.getPerformances())&&
             this.getDescription().equals(play.getDescription())&&
             this.getActors().equals(play.getActors())&&
             this.calcPrice(false, false)==play.calcPrice(false, false))
        {
            return true;
        }else
            return false;
    } 
    
    /**
     * Υποσκέλιση της μεθόδου hashCode
     * @return 
     */
     @Override
    public int hashCode(){
       int hash;
       hash=this.getName().hashCode();
       hash+=this.getDescription().hashCode();
       hash+=this.getDirector().hashCode()+101;
       return hash;
    }
    
    @Override
    public String toString()
    {
        return this.getName();
    }
    
     @Override
      public int compareTo(Play play)
    {
        return this.getName().compareTo(play.getName());
    }
}
