package project;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *H κλάση αυτή αναπαριστά τα στοιχεία της καρτέλας ενός χρήστη,τα στοιχεία επικοινωνίας μ αυτόν(phone) και τις κρατήσεις του(ένας χάρτης που σαν κλειδί
 * θα παίρνει ένα έργο(play) και θα αυτό θα οδηγεί στις κρατησεις(Reservation) που έχουν γίνει για αυτό το έργο).
 * 
 * @author Moustakas/Mpenos
 */
public class UserData implements Serializable{
    private String phone;
    private HashMap<Play,ArrayList<Reservation>> reservations; 

    
    /**
     * Πρόκειται για τον constructor της κλάσης o οποίος αναθέτει το τηλέφωνο(phone) που επιθυμεί ο χρήστης και δεσμεύει χώρο για τον χάρτη με τις κρατήσεις(reservations).
     * @param phone   το τηλέφωνο που επιθυμεί ο χρήστης.
     */
    public UserData(String phone)
    {
        this.phone=phone;
        reservations=new HashMap<>();
    }
    
    /**
     * @return το τηλέφωνο(phone)
     */
    public String getPhone() 
    {
        return phone;
    }

    /**
     * αναθέτει το τηλέφωνο(phone) που επιθυμεί ο χρήστης στο πεδίο τηλέφωνο του αντικειμένου που την καλεί.
     * @param phone το τηλέφωνο που επιθυμεί ο χρήστης να πάρει το αντικείμενο που δημιουργείται.
     */
    public void setPhone(String phone)
    {
        this.phone=phone;
    }
    
    /**
     * προσθέτει μια κράτηση(res) για ένα έργο(play) στις κρατήσεις(reservations) του χρήστη.
     * @param play το έργο.
     * @param res η  κράτηση.
     */
    public void addReservation(Play play,ArrayList<Reservation> res)
    {
        getReservations().put(play,res);
    }
    
    /**
     * διαγράφει μια κράτηση για ένα έργο(play) από τις κρατήσεις(reservations) του χρήστη.
     * @param play το έργο.
     */
    public void deleteReservation(Play play)
    {
        getReservations().remove(play);
    }

    /**
     * @return τον χάρτη με τις κρατήσεις.
     */
    public HashMap<Play, ArrayList<Reservation>> getReservations() {
        return reservations;
    }

    

}
