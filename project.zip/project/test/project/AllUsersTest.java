/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.HashMap;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class AllUsersTest 
{
    
    private User userA;
    private User userB;
    private AllUsers users;
    
    public AllUsersTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        userA = new User("Aris", "1234");
        userB = new User("Kostas", "5678");
        users = new AllUsers();
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of addUser method, of class AllUsers.
     */
    @Test
    public void testAddUser() 
    {
        UserData aData = users.addUser(userA, "123456");
        UserData bData = users.addUser(userB, "987456");
        if(aData == null || bData == null)
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of loginUser method, of class AllUsers.
     */
    @Test
    public void testLoginUser() 
    {
        users.addUser(userA, "123456");
        UserData aData=users.loginUser(userA);
        UserData bData=users.loginUser(userB);
        assertEquals(bData,null);
        assertEquals(aData.getPhone(),"123456");
    }

    /**
     * Test of getAllUsers method, of class AllUsers.
     */
    @Test
    public void testGetAllUsers() 
    {
        HashMap<User,UserData> testUsers = new HashMap<>();
        assertEquals(users.getAllUsers(), testUsers);
        UserData testData = new UserData("123");
        testUsers.put(userA, testData);
        users.addUser(userA, "123");
        assertEquals(users.getAllUsers(),testUsers);
    }

    /**
     * Test of usrChangePw method, of class AllUsers.
     */
    @Test
    public void testUsrChangePw() 
    {
        users.addUser(userB, "123456");
        users.usrChangePw(userB, "1111");
        if(!(userB.getPassword().equals("1111")))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of usrChangePhone method, of class AllUsers.
     */
    @Test
    public void testUsrChangePhone() 
    {
        UserData testData = new UserData("121212");
        users.getAllUsers().put(userA, testData);
        users.usrChangePhone(userA, "2222");
        if(!(testData.getPhone().equals("2222")))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of saveUsers method, of class AllUsers.
     */
  /*  @Test
    public void testSaveUsers() 
    {
        users.addUser(userA,"12345");
        users.saveUsers();
        try(ObjectInputStream data=new ObjectInputStream(new BufferedInputStream(new FileInputStream("users.dat"))))
        {
            AllUsers testUsers = (AllUsers)data.readObject();
            if(!(testUsers.equals(users)))
            {
                fail("Error!!!");
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
            fail("Problem in file reading...");
        }
    }*/
    
}
