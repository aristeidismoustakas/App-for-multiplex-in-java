/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class CinemaTest 
{
    Cinema cinema;
    SetOfSeats seats;
    RowOfSeats row;
    Seat seat;
    
    public CinemaTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        seat = new Seat(false, true);
        row = new RowOfSeats();
        row.addSeat(seat);
        seats = new SetOfSeats();
        seats.addRow(row);
        cinema = new Cinema("Cinema", seats, "ExampleSound");
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of getSoundSystem method, of class Cinema.
     */
    @Test
    public void testGetSoundSystem() 
    {
        assertEquals(cinema.getSoundSystem(), "ExampleSound");
    }

    /**
     * Test of getScreens method, of class Cinema.
     */
    @Test
    public void testGetScreens() 
    {
        assertEquals(cinema.getScreens(), new ArrayList<>());
    }

    /**
     * Test of setSoundSystem method, of class Cinema.
     */
    @Test
    public void testSetSoundSystem() 
    {
        cinema.setSoundSystem("ExampleSoundSystem");
        assertEquals(cinema.getSoundSystem(), "ExampleSoundSystem");
    }


        /**
     * Test of setScreens method, of class Cinema.
     */
    @Test
    public void testSetScreens() 
    {
        MovieScreen screen = new MovieScreen(80, true);
        ArrayList<MovieScreen> screens = new ArrayList<>();
        screens.add(screen);
        cinema.setScreens(screens);
        assertEquals(cinema.getScreens(), screens);
    }
  

  

    /**
     * Test of toString method, of class Cinema.
     */
    @Test
    public void testToString() 
    {
        assertEquals(cinema.toString(), cinema.getName());
    }

    
}
