/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author USER
 */
public class CinematicFilmTest {
    CinematicFilm film;
    public CinematicFilmTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
     film=new CinematicFilm("titanikos", "wraia", "kapoios",125);
     CinematicFilm.setPrice(15); 
     CinematicFilm.setPlusDelux(10);
     CinematicFilm.setPlus3D(5);
    }
    
    @After
    public void tearDown() {
        
    }

    /**
     * Test of getDuration method, of class CinematicFilm.
     */
    @Test
    public void testGetDuration() {
        assertEquals(film.getDuration(),125,0);
       
    }

    /**
     * Test of getPrice method, of class CinematicFilm.
     */
    @Test
    public void testGetPrice() {
        assertEquals(CinematicFilm.getPrice(), 15,0);
    }

    /**
     * Test of getPlus3D method, of class CinematicFilm.
     */
    @Test
    public void testGetPlus3D() {
        assertEquals(CinematicFilm.getPlus3D(),5,0);
    }

    /**
     * Test of getPlusDelux method, of class CinematicFilm.
     */
    @Test
    public void testGetPlusDelux() {
        assertEquals(CinematicFilm.getPlusDelux(),10,0);
    }

    /**
     * Test of setDuration method, of class CinematicFilm.
     */
    @Test
    public void testSetDuration() {
        film.setDuration(110);
        assertEquals(film.getDuration(),110,0);
    }

    /**
     * Test of setPlus3D method, of class CinematicFilm.
     */
    @Test
    public void testSetPlus3D() {
        CinematicFilm.setPlus3D(8);
        assertEquals(CinematicFilm.getPlus3D(),8,0);
    
    
    }

    /**
     * Test of setPlusDelux method, of class CinematicFilm.
     */
    @Test
    public void testSetPlusDelux() {
        CinematicFilm.setPlusDelux(9);
        assertEquals(CinematicFilm.getPlusDelux(),9,0);
       
       
    }

    /**
     * Test of setPrice method, of class CinematicFilm.
     */
    @Test
    public void testSetPrice() {
      CinematicFilm.setPlus3D(7);
      assertEquals(CinematicFilm.getPlus3D(),7,0);
    }

    /**
     * Test of calcPrice method, of class CinematicFilm.
     */
    @Test
    public void testCalcPrice() {
      double p=film.calcPrice(true, true);
        assertEquals(p,30,0);
    }

    /**
     * Test of equals method, of class CinematicFilm.
     */
    @Test
    public void testEquals() {
       CinematicFilm film2=new CinematicFilm("titanikos", "wraia", "kapoios",125);
        assertEquals(film2, film);
    }

    
    /**
     * Test of hashCode method, of class CinematicFilm.
     */
    @Test
    public void testHashCode() {
        CinematicFilm film2=new CinematicFilm("titanikos", "wraia", "kapoios",125);
        assertEquals(film2.hashCode(), film.hashCode());
 
    }

    /**
     * Test of toString method, of class CinematicFilm.
     */
   
     @Test
    public void testToString() {
        assertEquals(film.toString(),"titanikos");
    }
}
