/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class HallTest 
{
    Hall hall;
    SetOfSeats seats;
    
    public HallTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        seats = new SetOfSeats();
        hall = new TheatricalHall("Theater", seats, 3);
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of getName method, of class Hall.
     */
    @Test
    public void testGetName() 
    {
        assertEquals(hall.getName(), "Theater");
    }

    /**
     * Test of setName method, of class Hall.
     */
    @Test
    public void testSetName() 
    {
        hall.setName("TheaterHall");
        assertEquals(hall.getName(), "TheaterHall");
    }

    /**
     * Test of getSeats method, of class Hall.
     */
    @Test
    public void testGetSeats() 
    {
        assertEquals(hall.getSeats(), seats);
    }

    /**
     * Test of getCapacity method, of class Hall.
     */
    @Test
    public void testGetCapacity() 
    {
        
    }

    /*public class HallImpl extends Hall {

        public HallImpl() {
            super("", null);
        }

        public int getCapacity() {
            return 0;
        }
    }*/
    
}
