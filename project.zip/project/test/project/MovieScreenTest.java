/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class MovieScreenTest 
{
    MovieScreen screen;
    
    public MovieScreenTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        screen = new MovieScreen(80.0, true);
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of getSize method, of class MovieScreen.
     */
    @Test
    public void testGetSize() 
    {
        assertEquals(80.0, screen.getSize(),0.1);
    }

    /**
     * Test of getThreeDim method, of class MovieScreen.
     */
    @Test
    public void testGetThreeDim() 
    {
        assertEquals(screen.getThreeDim(), true);
    }

    /**
     * Test of setSize method, of class MovieScreen.
     */
    @Test
    public void testSetSize() 
    {
        screen.setSize(100);
        assertEquals(screen.getSize(), 100.0,0.1);
    }

    /**
     * Test of setThreeDim method, of class MovieScreen.
     */
    @Test
    public void testSetThreeDim() 
    {
        screen.setThreeDim(false);
        assertEquals(screen.getThreeDim(), false);
    }


}
