/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author USER
 */
public class PerformanceDetailsTest {
    PerformanceDetails det;
    public PerformanceDetailsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        det=new PerformanceDetails(new Date(2000, 01, 01, 12, 00),null);
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getDay method, of class PerformanceDetails.
     */
    @Test
    public void testGetDay() {
        assertEquals(det.getDay(), new Date(2000, 01, 01, 12, 00));
    }

    /**
     * Test of setDay method, of class PerformanceDetails.
     */
    @Test
    public void testSetDay() {
       det.setDay(new Date(2014, 01, 01, 12, 00));
        assertEquals(det.getDay(), new Date(2014, 01, 01, 12, 00));
    }

    /**
     * Test of getHall method, of class PerformanceDetails.
     */
    @Test
    public void testGetHall() {
        assertEquals(det.getHall(), null);
    }



    /**
     * Test of toString method, of class PerformanceDetails.
     */
    @Test
    public void testToString() {
        // assertEquals(det.toString(),"Ημερομηνία: "+01+"/"+01+"/"+2000+"   Ώρα: "+12+":"+00+"  Αίθουσα: "+"aaa");
       
    }
    
}
