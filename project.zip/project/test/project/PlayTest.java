/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.HashSet;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class PlayTest 
{
    Play play;
    
    public PlayTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        play = new TheatricalPlay("ExampleName", "ExampleDescription", "ExampleDirector", 0);
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of getName method, of class Play.
     */
    @Test
    public void testGetName() 
    {
        assertEquals(play.getName(), "ExampleName");
    }

    /**
     * Test of setName method, of class Play.
     */
    @Test
    public void testSetName() 
    {
        play.setName("Movie");
        assertEquals(play.getName(), "Movie");
    }

    /**
     * Test of getDescription method, of class Play.
     */
    @Test
    public void testGetDescription() 
    {
        assertEquals(play.getDescription(), "ExampleDescription");
    }

    /**
     * Test of setDescription method, of class Play.
     */
    @Test
    public void testSetDescription() 
    {
        play.setDescription("Description");
        assertEquals(play.getDescription(), "Description");
    }

    /**
     * Test of getDirector method, of class Play.
     */
    @Test
    public void testGetDirector() 
    {
        assertEquals(play.getDirector(), "ExampleDirector");
    }

    /**
     * Test of setDirector method, of class Play.
     */
    @Test
    public void testSetDirector() 
    {
        play.setDirector("Director");
        assertEquals(play.getDirector(), "Director");
    }

    /**
     * Test of getActors method, of class Play.
     */
    @Test
    public void testGetActors() 
    {
        assertEquals(play.getActors(),new HashSet<>());
    }

    /**
     * Test of setActors method, of class Play.
     */
    @Test
    public void testSetActors() 
    {
        HashSet<String> actrs = new HashSet<>();
        actrs.add("ExampleActor");
        play.setActors(actrs);
        assertEquals(play.getActors(), actrs);
    }

    /**
     * Test of getPerformances method, of class Play.
     */
    @Test
    public void testGetPerformances() 
    {
        assertEquals(play.getPerformances(), new HashSet<>());
    }

    /**
     * Test of setPerformances method, of class Play.
     */
    @Test
    public void testSetPerformances() 
    {
        HashSet<PerformanceDetails> perfs = new HashSet<>();
        PerformanceDetails perfD = new PerformanceDetails(null, null);
        perfs.add(perfD);
        play.setPerformances(perfs);
        assertEquals(play.getPerformances(), perfs);
    }

    /**
     * Test of toString method, of class Play.
     */
    @Test
    public void testToString() 
    {
        assertEquals(play.getName(), play.toString());
    }

    /**
     * Test of calcPrice method, of class Play.
     */
    @Test
    public void testCalcPrice() 
    {
    }

    /*public class PlayImpl extends Play {

        public PlayImpl() {
            super("", "", "");
        }*/

        public double calcPrice(boolean del, boolean ThreeDim) {
            return 0.0;
        }
    }
    

