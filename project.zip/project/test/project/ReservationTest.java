/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;
import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class ReservationTest 
{
    PerformanceDetails perfD;
    Reservation res;
    
    public ReservationTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        Date day = new Date();
        SetOfSeats seats = new SetOfSeats();
        Hall hall = new TheatricalHall("Hall", seats, 3);
        perfD = new PerformanceDetails(day,hall);
        res = new Reservation(perfD);
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of getDetails method, of class Reservation.
     */
    @Test
    public void testGetDetails() 
    {
        assertEquals(res.getDetails(), perfD);
    }

    /**
     * Test of setDetails method, of class Reservation.
     */
    @Test
    public void testSetDetails() 
    {
        Date day = new Date();
        SetOfSeats seats = new SetOfSeats();
        Hall hall = new TheatricalHall("Theater",seats,5);
        PerformanceDetails perf = new PerformanceDetails(day,hall);
        res.setDetails(perf);
        assertEquals(res.getDetails(), perf);
    }

    /**
     * Test of addSeats method, of class Reservation.
     */
    @Test
    public void testAddSeats() 
    {
        SeatRes sRes = new SeatRes(10, 10, 0);
        ArrayList<SeatRes> seatRes = new ArrayList<>();
        seatRes.add(sRes);
        res.addSeats(seatRes);
        assertEquals(seatRes, res.getSeatsRes());
    }

    /**
     * Test of deleteSeatRes method, of class Reservation.
     */
    @Test
    public void testDeleteSeatRes() 
    {
        SeatRes sRes = new SeatRes(10, 10, 0);
        ArrayList<SeatRes> seatRes = new ArrayList<>();
        seatRes.add(sRes);
        res.addSeats(seatRes);
        if(res.getSeatsRes().size() != 1)
        {
            fail("Error!!!");
        }
        res.deleteSeatRes(10, 10, 0);
        if(!res.getSeatsRes().isEmpty())
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of getSeatsRes method, of class Reservation.
     */
    @Test
    public void testGetSeatsRes() 
    {
        assertEquals(res.getSeatsRes(), new ArrayList<>());
    }

 
    
}
