/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class RowOfSeatsTest 
{
    RowOfSeats row;
    
    public RowOfSeatsTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        row = new RowOfSeats();
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of addSeat method, of class RowOfSeats.
     */
    @Test
    public void testAddSeat() 
    {
        Seat seat = new Seat(true, true);
        row.addSeat(seat);
        if(!row.getRow().contains(seat))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of getRow method, of class RowOfSeats.
     */
    @Test
    public void testGetRow() 
    {
        assertEquals(row.getRow(), new ArrayList<>());
    }

    /**
     * Test of setRow method, of class RowOfSeats.
     */
    @Test
    public void testSetRow() 
    {
        ArrayList<Seat> seats = new ArrayList<>();
        row.setRow(seats);
        assertEquals(row.getRow(), new ArrayList());
    }

    /**
     * Test of getNumOfSeats method, of class RowOfSeats.
     */
    @Test
    public void testGetNumOfSeats() 
    {
        assertEquals(row.getNumOfSeats(), 0);
    }


    
}
