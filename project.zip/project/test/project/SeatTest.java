/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class SeatTest 
{
    Seat seat;
    
    public SeatTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        seat = new Seat(false, false);
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of getDelux method, of class Seat.
     */
    @Test
    public void testGetDelux() 
    {
        assertEquals(seat.getDelux(), false);
    }

    /**
     * Test of getEmpty method, of class Seat.
     */
    @Test
    public void testGetEmpty() 
    {
        assertEquals(seat.getEmpty(), false);
    }

    /**
     * Test of setDelux method, of class Seat.
     */
    @Test
    public void testSetDelux() 
    {
        seat.setDelux(true);
        assertEquals(seat.getDelux(), true);
    }

    /**
     * Test of setEmpty method, of class Seat.
     */
    @Test
    public void testSetEmpty() 
    {
        seat.setEmpty(true);
        assertEquals(seat.getEmpty(), true);
    }


    }
    

