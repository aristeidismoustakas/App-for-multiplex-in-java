/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class SetOfSeatsTest 
{
    SetOfSeats seats;
    
    public SetOfSeatsTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        seats = new SetOfSeats();
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of addRow method, of class SetOfSeats.
     */
    @Test
    public void testAddRow() 
    {
        RowOfSeats row = new RowOfSeats();
        seats.addRow(row);
        if(!seats.getList().contains(row))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of getList method, of class SetOfSeats.
     */
    @Test
    public void testGetList() 
    {
        assertEquals(seats.getList(), new ArrayList<>());
    }

    /**
     * Test of setList method, of class SetOfSeats.
     */
    @Test
    public void testSetList() 
    {
        ArrayList<RowOfSeats> rows = new ArrayList<>();
        seats.setList(rows);
        assertEquals(seats.getList(), new ArrayList<>());
    }

    /**
     * Test of getTotalNumOfSeats method, of class SetOfSeats.
     */



    
}
