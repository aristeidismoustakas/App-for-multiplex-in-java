/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class TheatricalHallTest 
{
    TheatricalHall hall;
    SetOfSeats seats;
    
    public TheatricalHallTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        seats = new SetOfSeats();
        hall = new TheatricalHall("Theater",seats,3);
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of getDressingRooms method, of class TheatricalHall.
     */
    @Test
    public void testGetDressingRooms() 
    {
        assertEquals(hall.getDressingRooms(), 3);
    }

 
    /**
     * Test of setDressingRooms method, of class TheatricalHall.
     */
    @Test
    public void testSetDressingRooms() 
    {
        hall.setDressingRooms(10);
        assertEquals(hall.getDressingRooms(), 10);
    }


    /**
     * Test of getCapacity method, of class TheatricalHall.
     */
    @Test
    public void testGetCapacity() 
    {
        assertEquals(hall.getCapacity(), 0);
    }

    /**
     * Test of equals method, of class TheatricalHall.
     */
    @Test
    public void testEquals() 
    {
        TheatricalHall theater = new TheatricalHall("Theater", seats, 3);
        assertEquals(theater, hall);
        theater.setDressingRooms(5);
        if(theater.equals(hall))
        {
            fail("Error!!!");
        }
        theater.setDressingRooms(3);
        theater.setName("ExampleTheater");
        if(theater.equals(hall))
        {
            fail("Error!!!");
        }
        SetOfSeats testSet = new SetOfSeats();
        testSet.addRow(new RowOfSeats());
        TheatricalHall testTheater = new TheatricalHall("Theater", testSet, 3);
        if(testTheater.equals(hall))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of toString method, of class TheatricalHall.
     */
    @Test
    public void testToString() 
    {
        if(!hall.getName().equals(hall.toString()))
        {
            fail("Error!!!");
        }
    }
    
}
