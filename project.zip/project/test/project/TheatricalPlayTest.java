/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author USER
 */
public class TheatricalPlayTest {
    TheatricalPlay play;
    public TheatricalPlayTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        play=new TheatricalPlay("aa", "bb", "cc", 1.1);
        
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of calcPrice method, of class TheatricalPlay.
     */
    @Test
    public void testCalcPrice() {
        assertEquals(play.calcPrice(false, false), 1.1,0);
     
    }

    /**
     * Test of setPrice method, of class TheatricalPlay.
     */
    @Test
    public void testSetPrice() {
        play.setPrice(2.1);
        assertEquals(play.calcPrice(false, false), 2.1,0);
    
    }

    /**
     * Test of equals method, of class TheatricalPlay.
     */
    @Test
    public void testEquals() {
       TheatricalPlay play2=new TheatricalPlay("aa", "bb", "cc", 1.1);
        assertEquals(play2, play);
      play2.setPrice(2.0);
      if(play.equals(play2))
      { 
          fail();
      }
    }

    /**
     * Test of hashCode method, of class TheatricalPlay.
     */
    @Test
    public void testHashCode() {
        TheatricalPlay play2=new TheatricalPlay("aa", "bb", "cc", 1.1);
        assertEquals(play2.hashCode(),play.hashCode(),0);
    
    }

    /**
     * Test of toString method, of class TheatricalPlay.
     */
    @Test
    public void testToString() {
        assertEquals(play.toString(), "aa");
        
    }
    
}
