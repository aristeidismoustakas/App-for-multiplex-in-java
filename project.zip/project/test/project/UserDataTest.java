/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Date;
import java.util.HashMap;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class UserDataTest 
{
    UserData userData;
    
    public UserDataTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() 
    {
        userData = new UserData("1234");
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getPhone method, of class UserData.
     */
    @Test
    public void testGetPhone() 
    {
        if(!(userData.getPhone().equals("1234")))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of setPhone method, of class UserData.
     */
    @Test
    public void testSetPhone() 
    {
        userData.setPhone("111222");
        if(!(userData.getPhone().equals("111222")))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of addReservation method, of class UserData.
     */
    @Test
    public void testAddReservation() 
    {
        Play p=new TheatricalPlay("example", "example", "example", 0);
        userData.addReservation(p, null);
        if(!userData.getReservations().keySet().contains(p))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of deleteReservation method, of class UserData.
     */
    @Test
    public void testDeleteReservation() 
    {
        Play p=new TheatricalPlay("as", "q", "w", 0);
        userData.addReservation(p, null);
        userData.deleteReservation(p);
        if(userData.getReservations().keySet().contains(p))
        {
            fail("Error");
        }
    }



}
