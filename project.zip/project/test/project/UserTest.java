/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kostas
 */
public class UserTest 
{
    User userA;
    User userB;
    
    public UserTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass() 
    {
    }
    
    @AfterClass
    public static void tearDownClass() 
    {
    }
    
    @Before
    public void setUp() 
    {
        userA = new User(null,null);
        userB = new User("Kostas", "1234");
    }
    
    @After
    public void tearDown() 
    {
    }

    /**
     * Test of setUsername method, of class User.
     */
    @Test
    public void testSetUsername() 
    {
        userA.setUsername("Example");
        userB.setUsername("Example2");
        if(userB.getUsername().equals("Kostas"))
        {
            fail("Error!!!");
        }
        assertEquals(userA.getUsername(), "Example");
    }

    /**
     * Test of setPassword method, of class User.
     */
    @Test
    public void testSetPassword() 
    {
        userA.setPassword("1111");
        assertEquals(userA.getPassword(),"1111");
    }

    /**
     * Test of getUsername method, of class User.
     */
    @Test
    public void testGetUsername() 
    {
        assertEquals(userB.getUsername(), "Kostas");
        assertEquals(userA.getUsername(), null);
    }

    /**
     * Test of getPassword method, of class User.
     */
    @Test
    public void testGetPassword() 
    {
        assertEquals(userA.getPassword(), null);
        assertEquals(userB.getPassword(), "1234");
    }

    /**
     * Test of equals method, of class User.
     */
    @Test
    public void testEquals() 
    {
        userA.setUsername("Kostas");
        userA.setPassword("1234");
        if(!(userA.equals(userB)))
        {
            fail("Error!!!");
        }
        userA.setUsername("Arhs");
        if(userA.equals(userB))
        {
            fail("Error!!!");
        }
        userA.setUsername("Kostas");
        userA.setPassword("1111");
        if(userA.equals(userB))
        {
            fail("Error!!!");
        }
    }

    /**
     * Test of hashCode method, of class User.
     */
    @Test
    public void testHashCode() 
    {
        userA.setUsername("Kostas");
        userA.setPassword("1234");
        if(userA.hashCode() != userB.hashCode())
        {
            fail("Error!!!");
        }
    }
    
}
